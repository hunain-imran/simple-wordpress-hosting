All designs are from internet, templates and others from colorlib and other!

Open Source wordpress zip file should be edited in order to change database information

Data/wordpress/index.php has redirect URL at last with port 8003, redirect to you the port on which client's websites are running, eirher you can change it or you can setup domain-based conditon on web server.

On your webserver, there must be either two ports handing or if-else condition. one port for managing whole website, such as creating website or user data, Second port for "websites" folder where websites are located

I have configured web server in such a way that it serve specific folder of website according to domain name, so if domain name is "example.com", it will serve "example.com" folder located under "websites" folder.

mySQL database is already saved in Data folder

Uses unzipper.php from Github

Download wordpress.zip in Data/wordpress

Configure Database information in Data/wordpress/wp-config

Create website by going to /create/