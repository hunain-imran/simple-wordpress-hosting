<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'WPuser' );

/** MySQL database username */
define( 'DB_USER', 'WPuser' );

/** MySQL database password */
define( 'DB_PASSWORD', 'I!Nrm!Q14[0roW)I' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'u2 ^yeR>7Heq >GbiuZCBJVBT(r+SJD41`jO$HV#WuF3#~y8At#e/@`YTX0@2Rd2' );
define( 'SECURE_AUTH_KEY',  'WBj;dEJFP9zOt8Nd1w.sruE4sSZ~GZDK^l1Le?>up3L-[4>VNdXD^WdTiN,D<%JH' );
define( 'LOGGED_IN_KEY',    'P]Ijc6r1gO;Bo^,o]l7/3;n8ryV/7;^WtI-:X9Oe-,e!]68Mt:G(r[vWb`NKAYr<' );
define( 'NONCE_KEY',        '8<w7[/%5i,~?&x|h#njDh>SQb6F:Hx@!.:nO1bWPP6c%Ra[M}+1_sI$S^Hpzq}w_' );
define( 'AUTH_SALT',        'OKFtI1p2r7jHgj(ji1E{;pc [awe!`un_L3Bv~sw:6M>nEzEwQn%ZBr;h3Pu/GRz' );
define( 'SECURE_AUTH_SALT', 'rlH1t#ky26[itBfZ#cK3M!,k3V!pa!Tu7)#sW47B>n(&!S m~G/bO4lD*+LlbVy+' );
define( 'LOGGED_IN_SALT',   'nIKfM1gw`%BD+>j21IUBLgHc^Zu$!4w8O^u:)u`!v3fATB W,a9aILbv!13sFw]?' );
define( 'NONCE_SALT',       'ua-o2I@AEH2$E/ZCzBI`q5W<YPrtUZ?Lc~Ma?]s)7;Vk`I27;at5Q3pD(Ln)bnM|' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
 $file = fopen("http://localhost:8002/Data/users/".str_replace(":".$_SERVER['SERVER_PORT'],"",$_SERVER['HTTP_HOST']),"r");

$table_prefix = fgets($file);

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
